"""
The MIT License (MIT)

Copyright (c) 2016 Eduardo Henrique Vieira dos Santos

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""

from __future__ import division	#prevents error while doing float division in python
import math, random 	#useful for our purposes


class Neuron:

	#This class means the Neurons in our Network
	#A Neuron belongs to Dendrites

	#Neurons calculate its Activation based on the sum of inputs given
	#Its Activation is represented by a Sigmoid function

	
	################
	### Settings ###
	################

	def __init__(self,pw,gw,bend, xn, gwn):
		self.setPw(pw)	#Private Weight
		self.setGw(gw)	#Global Weight
		self.setBend(bend)	#Function Bend
		self.injectSumXn(xn)	#Sum of Xn elements activation
		self.injectSumGWn(gwn)	#Sum of those elements Global Weights
		self.act = 0	#Default activation value

	def setPw(self, w):
		#Neuron Private Weight
		self.pW = w
	def getPw(self):
		return self.pW

	def setGw(self, w):
		#Neuron Global Weight
		self.gW = w
	def getGw(self):
		return self.gW

	def setBend(self, bend):
		#activation function Bend factor
		if bend > 0.5:
			bend = 1	#Sigmoid function with 1 as bend decrease as progress
		else:
			bend = -1	#Sigmoid function with 1 as bend increase as progress
		self.bend = bend
	def getBend(self):
		return self.bend

	######################
	## Inputs & Outputs ##
	######################

	def injectSumXn(self, xn):
		#Inject the sum of Xn elements activation value into Neuron
		self.sumXn = xn
	def getSumXn(self):
		return self.sumXn

	def injectSumGWn(self, gwn):
		#Inject the sum of those elements Global Weights
		self.sumGwn = gwn
	def getSumGWn(self):
		return self.sumGwn

	################
	### Purposes ###
	################

	def newRandom(self):
		#Reconfigure Neuron to random Setting values
		self.setPw(random.random())
		self.setGw(random.random())
		self.setBend(random.random())
		self.act = 0

	def setAct(self):
		#Sigmoid activation
		if self.getSumGWn() == 0:
			#once 0 cannot be divider
			k = 0
		else:
			#Do the proportion of Activations(sum) by Global Wieghts(sum)
			k = self.getSumXn() / self.getSumGWn()
		#Force it through Neuron Private Weight
		k = k * self.getPw()
		#Calculates the exponent with k
		k = self.bend*math.e*(k*2-1)
		#Does the power between e(Euler's Number) by k
		k = math.exp(k)
		#Sum its results with 1
		k = 1+(k)
		#Does the fraction
		k = 1/k
		#Set the new Activation value into self.act by Neuron Global Weight
		self.act = k
	def getAct(self):
		#Get Neuron Activation value
		return self.act


#tests
#n = Neuron(random.random(), random.random(), random.random(), 0.3, 0.2)
#n.setAct()
#print n.getAct()
#print n.getGw(), n.getPw(), n.getBend()," in ", n.getSumXn(), n.getSumGWn()
#x = Neuron(random.random(), random.random(), random.random(), n.getAct(), n.getGw())
#x.setAct()
#print x.getAct()
#print x.getGw(), x.getPw(), x.getBend()," in ", x.getSumXn(), x.getSumGWn()
#y = Neuron(random.random(), random.random(), random.random(), x.getAct(), x.getGw())
#y.setAct()
#print y.getAct()
#print y.getGw(), y.getPw(), y.getBend()," in ", y.getSumXn(), y.getSumGWn()

