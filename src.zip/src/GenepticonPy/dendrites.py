"""
The MIT License (MIT)

Copyright (c) 2016 Eduardo Henrique Vieira dos Santos

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""

import neuron 	#import the classes inside neuron.py

class Dendrites:

	#Dendrites means a layer containing Neurons
	#A Dendrites belongs to Layer (its coating)

	#Dendrites inject the Xn and GWn sums of other Dendrites or Network Inputs into its Neurons
	#Then Neurons are activated
	#Their Activation and Global Weight values are ejected from the Dendrites as lists
	#Dendrites does the sums of Xn Neurons activations and its Global Weights inside its NeuronList

	################
	### Settings ###
	################

	def __init__(self):
		self.setNeuronList([])	#List of Neurons inside the Dendrites
		self.setInputXn([])	#List of Xn inputs where X is another Dendrites output or a Network Input
		self.setInputGWn([])	#List of Global Weights from those Inputs if its Neurons activation
		self.setOutputXn()	#Sum of inner Neurons Activation inside NeuronList
		self.setOutputGWn()	#Sum of inner Global Weights of those Neurons

	###############
	### Neurons ###
	###############

	def setNeuronList(self,nLis):
	 #NeuronList must be a list type object
		self.NeuronList = nLis
	def getNeuronList(self):
		return self.NeuronList

	######################
	## Inputs & Outputs ##
	######################

	def setInputXn(self,nXn):
		#Set the list of Xn inputs where X is another Dendrites output or a Network Input
		self.inputXn = nXn
	def getInputXn(self):
		return self.inputXn

	def setInputGWn(self,nLis):
		#Set the Global Weights from those Inputs if its Neurons activations
		self.inputGWn = nLis
	def getInputGWn(self):
		return self.inputGWn

	def setOutputXn(self):
		#Eject the inner Neurons Activation value into outputXn[]
		self.outputXn = []
		if len(self.NeuronList) != 0:
			for i in self.NeuronList:
				self.outputXn.append(i.getAct())
	def getOutputXn(self):
		#Get inner Neurons Activation list
		return self.outputXn

	def setOutputGWn(self):
		#Eject the inner Neurons Global Weight values into outputGWn[]
		self.outputGWn = []
		if len(self.NeuronList) != 0:
			for i in self.NeuronList:
				self.outputGWn.append(i.getGw())
	def getOutputGWn(self):
		#Get inner Neurons Global Weights list
		return self.outputGWn

	################
	### Purposes ###
	################

	def newRandom(self,length):
		#Reconfigure Dendrites to a list of Neurons with a length, each with random Settings
		self.NeuronList = []
		for i in range(length):
			n = neuron.Neuron(None, None, None, None, None)
			n.newRandom()
			self.NeuronList.append(n)

	def injectXn(self):
		#Inject the sum of Dendrites Xn inputs into the Neurons
		s = sum(self.inputXn)
		for i in self.NeuronList:
			i.injectSumXn(s)

	def injectGWn(self):
		#Inject the sum of Dendrites Global Weight inputs into the Neurons
		s = sum(self.inputGWn)
		for i in self.NeuronList:
			i.injectSumGWn(s)

	def activateNeurons(self):
		#Activate the inner Neurons in NeuronList
		for i in self.NeuronList:
			i.setAct()

	def activateInputDendrites(self):
		#Dendrites in Input Layer activation type
		#Each Network input is inserted into its correspondent Neuron
		for i in range(len(self.NeuronList)):
			neur = self.NeuronList[i]
			neur.injectSumXn(self.inputXn[i])
			neur.injectSumGWn(self.inputGWn[i])
			neur.setAct()	#Neuron is activated
		#eject the Neurons outputs
		self.setOutputXn()	#eject its Neurons activation values to Dendrites
		self.setOutputGWn()	#eject its Neurons Global Weight values to Dendrites

	def activateDendrites(self):
		#Dendrites in Hidden and Output Layer activation type
		self.injectXn()
		self.injectGWn()
		#The Neurons become activated
		self.activateNeurons()
		#eject the Neurons outputs
		self.setOutputXn()
		self.setOutputGWn()

"""









"""
