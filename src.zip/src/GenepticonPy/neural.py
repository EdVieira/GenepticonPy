#encoding:utf-8
"""
The MIT License (MIT)

Copyright (c) 2016 Eduardo Henrique Vieira dos Santos

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""

import network, layer, dendrites, copy, random, math

class Neural:

	#Neural is the class responsible for generate and training Networks based on Genetic Algorithm

	#It reads the settings of the deserved Network to be trainned
	#Generates populations based in the parents by using Crossover and Mutation concept
	#Selects the better individuals from the population and set them as parents to generate new solutions
	#Each individual is a solution (Network)
	#Each envirorment is a problem (deserved input to deserved output)
	#Each rank is an individual adaptation to the problem (Network Outputs deviation)
	#Rank Zero is the better one (Zero deviation)

	#Outputs a Network
	
	################
	### Settings ###
	################

	def __init__(self):
		self.name = "net"+str(self)	#Defines the name of the Output Network

		#Genetic Algorithm

		#Sexual reproduction between individuals
		self.parent1 = None	#Parent 1
		self.parent2 = None	#Parent 2

		#Network atributes
		self.heightInputLayer = 0	#Amount of Neurons in its Input Layer
		self.lenHiddenLayer = 0	#Amount of Dendrites in its Hidden Layer
		self.heightHiddenLayer = 0	#Amount of Neurons per Dendrites into its Hidden Layer
		self.heightOutputLayer = 0	#Amount of Neurons in its Output Layer

		self.deservedInputs = []	#List of Deserved Inputs to be passed for Network Ranking
		self.deservedOutputs = []	#List of Deserved Outputs for each of the above Inputs in list
		self.idealFitness = 0.01	#Ideal Network fitness, usually 1%
		self.mutationRate = 0.5	#Mutation rate
		self.populationSize = 50	#Size of each population during Selection
		self.population = []	#List of the population of Networks
		self.lifetimeCounter = 100	#Lifetime limit for parent 1 as population goes by


	##############
	## Networks ##
	##############
	def setName(self, n):
		#The name of the Output Network
		self.name = n
	def getName(self):
		return self.name

	def setParent1(self, parent):
		#Network parent 1 must is a Network type
		self.parent1 = parent
	def getParent1(self):
		return self.parent1

	def setParent2(self, parent):
		#Network parent 2 must is a Network type
		self.parent2 = parent
	def getParent2(self):
		return self.parent2

	def setNetworksLenghts(self, heightInputLayer, lenHiddenLayer, heightHiddenLayer, heightOutputLayer):
		#Settings of the deserved Network
		self.heightInputLayer = heightInputLayer
		self.lenHiddenLayer = lenHiddenLayer
		self.heightHiddenLayer = heightHiddenLayer
		self.heightOutputLayer = heightOutputLayer


	######################
	## Inputs & Outputs ##
	######################
	def setDeservedInputs(self,lis):
		#Deserved Inputs for Network rating
		self.deservedInputs = lis
	def addDeservedInput(self,i):
		#Adds a list of a input set
		self.deservedInputs.append(i)
	def getDeservedInputs(self):
		return self.deservedInputs

	def addInputToOutput(self, inp, outp):
		#inp means a list of Deserved Inputs for each index as a Neuron in its Network Input Layer
		self.deservedInputs.append(inp)
		#inp means a list of deserved onputs for each index as a Neuron in its Network Output Layer
		self.deservedOutputs.append(outp)

	def cleanDeservedIO(self):
		self.deservedInputs = []
		self.deservedOutputs = []

	def setDeservedOutputs(self,lis):
		#Deserved Outputs for each deservedInput
		self.deservedOutputs = lis
	def addDeservedOutput(self,i):
		#Add a list of a output set
		self.deservedOutputs.append(i)
		#The input and the output list must match in its lenghts
	def getDeservedOutputs(self):
		return self.deservedOutputs

	def setIdealFitness(self, f): #float
		#The ideal fitness that you're looking for your Network
		#Used as a stop clause while evolving the Network
		self.idealFitness = f
	def getIdealFitness(self):
		return self.idealFitness

	def setMutationRate(self, rate):	#float rate
		#Mutation rate over generetade individuals(Network) in population
		self.mutationRate = rate
	def getMutationRate(self):
		return self.mutationRate

	def setPopulationSize(self, size):	#int quantity
		#Amount of individuals(Network) in population
		self.populationSize = size
	def getPopulationSize(self):
		return self.populationSize

	def setPopulation(self, population):	#list with Networks
		#A set of a population
		self.population = population
	def getPopulation(self):
		return self.population

	def setIndividualRate(self, rate):	#list with floats
		#List that matches the index of the population as an individual and its respective rate(Rank)
		self.individualRate = rate


	def injectInput(self,net, inputs):
		#Used to inject the objects in Deserved Inputs list into the Network
		net.setInputXn(inputs)

	def setLifetimeCounter(self, i):
		#Defines the lifetimeCounter
		#Lifetime limit for parent1 as population goes by
		self.lifetimeCounter = i

	################
	### Purposes ###
	################

	def newRandom(self):
		#Generates a newRandom Network with the setted especifications in setNetworksLenghts()
		net = network.Network()
		net.newRandom(self.heightInputLayer, self.lenHiddenLayer, self.heightHiddenLayer, self.heightOutputLayer)
		#The mutation process attaches to the Network Input Layer Neurons Weights of 1
		net = self.mutation(net)
		return net

	def randomPopulate(self):
		#Generates a new random population to be selected for first
		self.population = []
		#Using the setted population size it generates random individuals
		for i in range(self.populationSize):
			self.population.append(self.newRandom())
		return True

	def populate(self, parent1, parent2, size):
		#Generates a new population using parent1 and parent2 genes
		newPopulation = []
		#It is based on the setted population size
		for i in range(size):
			#Creates the Network
			net = network.Network()
			#Crossover its parents genes
			net = self.crossover(parent1, parent2)
			#Apply mutation over the individual attributes
			net = self.mutation(net)
			#Join the individual to the new population list
			newPopulation.append(net)
		#Overlap the population
		self.population = newPopulation

	def crossover(self, net1, net2):
		#Crossover process in sexual reproduction betwen two Networks

		inLay1 = net1.getInputLayer()	#gets Input, Hidden and Output Layer from Network1
		hiLay1 = net1.getHiddenLayer()
		ouLay1 = net1.getOutputLayer()

		inLay2 = net2.getInputLayer()	#gets Input, Hidden and Output Layer from Network2
		hiLay2 = net2.getHiddenLayer()
		ouLay2 = net2.getOutputLayer()

		inInLay1 = inLay1.getDendritesList()	#gets Dendrites list from each Layer in Network1
		hiInLay1 = hiLay1.getDendritesList()
		ouInLay1 = ouLay1.getDendritesList()

		inInLay2 = inLay2.getDendritesList()	#gets Dendrites list from each Layer in Network2
		hiInLay2 = hiLay2.getDendritesList()
		ouInLay2 = ouLay2.getDendritesList()

		net = network.Network()	#new Network
#		inLay = layer.Layer()	#new Input Layer
		hiLay = layer.Layer()	#new Hidden Layer
		ouLay = layer.Layer()	#new Output Layer

		#Input Layer crossover
#		LayersList = []
#		for i in range(len(inInLay1)):	#run trhough DendritesList from the net1 input layer
#			il = dendrites.Dendrites()
#
#			nList1 = inInLay1[i].getNeuronList()
#			nList2 = inInLay2[i].getNeuronList()
#			nList = []
#
#			for n in range(len(nList1)):	#copy 1/2 part from net1 and the rest from net2
#				if n > int(len(nList1)/2):
#					nList.append(nList1[n])
#				else:
#					nList.append(nList2[n])
#
#			il.setNeuronList(nList)
#
#			LayersList.append(copy.deepcopy(il))
#
#		inLay.setDendritesList(copy.deepcopy(LayersList))
#		net.setInputLayer(inLay1)

		#Set the Network Input Layer into the new Network	
		net.setInputLayer(inLay1)

		#Hidden Layer crossover

		#new Layer
		LayersList = []
		#Runs trhough Dendrites list from the Network1 Hidden Layer
		for i in range(len(hiInLay1)):
			#new Dendrites
			il = dendrites.Dendrites()

			#gets the Neuron list from Network1 and Network2
			nList1 = hiInLay1[i].getNeuronList()
			nList2 = hiInLay2[i].getNeuronList()
			#new list of Neurons
			nList = []

			for n in range(len(nList1)):	#Copies 1/2 part of Neuron list from Network1 and the rest from Network2
				if n > int(len(nList1)/2):
					nList.append(nList1[n])
				else:
					nList.append(nList2[n])

			#Sets the new Neuron list as the NeuronList() of the new Dendrites
			il.setNeuronList(nList)

			#Add the new Dendrites to the end of the new Layer
			LayersList.append(copy.deepcopy(il))

		#Sets the new Layer as the Hidden Layer
		hiLay.setDendritesList(copy.deepcopy(LayersList))
		#Set the Network Hidden Layer
		net.setHiddenLayer(hiLay)

		#Output Layer crossover
		LayersList = []
		for i in range(len(ouInLay1)):	#Run trhough DendritesList from the net1 output layer
			il = dendrites.Dendrites()

			nList1 = ouInLay1[i].getNeuronList()
			nList2 = ouInLay2[i].getNeuronList()
			nList = []

			for n in range(len(nList1)):
				if n > int(len(nList1)/2):
					nList.append(nList1[n])
				else:
					nList.append(nList2[n])

			il.setNeuronList(nList)

			LayersList.append(copy.deepcopy(il))

		ouLay.setDendritesList(copy.deepcopy(LayersList))
		net.setOutputLayer(ouLay)



######## Random mutation over parameters itself
#		for i in range(len(inInLay1)):
#			nLi = inInLay1.getNeuronList()
#			for n in range(len(nLi)):
#				r = random.random()
#				if r < 0.5:
#					nLi[n] = copy.deepcopy(inInLay2[n])
#					
#
#		for i in range(len(hiInLay1)):
#			nLi = hiInLay1.getNeuronList()
#			for n in range(len(nLi)):
#				r = random.random()
#				if r < 0.5:
#					nLi[n] = copy.deepcopy(hiInLay2[n])
#
#		for i in range(len(ouInLay1)):
#			nLi = ouInLay1.getNeuronList()
#			for n in range(len(nLi)):
#				r = random.random()
#				if r < 0.5:
#					nLi[n] = copy.deepcopy(ouInLay2[n])

		#returns the Network with its crossed genes
		return net


	def mutation(self, net1):
		#Mutation process into a Network

		net = copy.deepcopy(net1)
		inLay = net.getInputLayer()	#Gets Input, Hidden and Output Layer from Network
		hiLay = net.getHiddenLayer()
		ouLay = net.getOutputLayer()

		inInLay = inLay.getDendritesList()	#Gets Dendrites list from each Layer
		hiInLay = hiLay.getDendritesList()
		ouInLay = ouLay.getDendritesList()

		#Sets the Input Layer Weights as 1 and its bend as crescent to a Sigmoid Function
		for i in inInLay:	#
			nLi = i.getNeuronList()
			for n in nLi:
				#r = random.random()
				#if r < self.mutationRate:
				#	n.setPw(random.random())
				n.setPw(1)
				#r = random.random()
				#if r < self.mutationRate:
				#	n.setGw(random.random())
				n.setGw(1)
				#r = random.random()
				#if r < self.mutationRate:
				#	n.setBend(random.random())
				n.setBend(0)
				n.act = 0

		#Sets mutations over the attributes of each Neuron into the Hidden Layer
		for i in hiInLay:
			nLi = i.getNeuronList()
			for n in nLi:
				#random a number
				r = random.random()
				#If its in the amplitude of the mutation rate it changes to a random value
				if r < self.mutationRate:
					n.setPw(random.random())
				r = random.random()
				if r < self.mutationRate:
					n.setGw(random.random())
				r = random.random()
				if r < self.mutationRate:
					n.setBend(random.random())
				#reset the Neuron Activation value
				n.act = 0

		#Sets mutations over the attributes of each Neuron into the Output Layer
		for i in ouInLay:
			nLi = i.getNeuronList()
			for n in nLi:
				r = random.random()
				if r < self.mutationRate:
					n.setPw(random.random())
				r = random.random()
				if r < self.mutationRate:
					n.setGw(random.random())
				r = random.random()
				if r < self.mutationRate:
					n.setBend(random.random())
				n.act = 0

		#returns the mutated Network
		return net

	def rank(self, net):
		#Calculates the deviation between the Network Activation Outputs for each Deserved Input to each Deserved Output
		deviationSum = 0
		#Tests each Deserved Inputs for each Deserved Output
		for i in range(len(self.deservedInputs)):
			#Activates the Network with the deserved input
			z = net.activateNetwork(self.deservedInputs[i])
			#Compare each output...
			for j in range(len(z)):
				major = z[j]
				minor = self.deservedOutputs[i][j]
				#Compare the Network Outputs to the Deserved Output
				if self.deservedOutputs[i][j] > major:
					major = self.deservedOutputs[i][j]
					minor = z[j]
				distance = major - minor
				if distance > 0.5:
					#if the distance of the goal is in the wrong direction it doubles its distance
					distance = distance + distance
				deviationSum = deviationSum + distance
		#Return the sum of the deviations between the Network Outputs and the Deserved Outputs
		return deviationSum

	


	def selection(self):
		#Compares the Rank of each individual into the population and chooses the better ones to be parents
		rank1 = float("inf")
		rank2 = float("inf")
		for i in range(len(self.population)):
			
			rankI = self.rank(self.population[i])

			#If parents are not set
			if self.parent1 is None:
				self.parent1 = self.population[i]
			if self.parent2 is None and self.population[i] != self.parent1:
				self.parent2 = self.population[i]

			#If parents are set
			if self.parent1 != None:
				rank1 = self.rank(self.parent1)
			if self.parent2 != None:
				rank2 = self.rank(self.parent2)

			#Compare the invidual rank with the parent rank, if its better, it substitutes the parent
			if rankI < rank1:
				self.parent2 = self.parent1
				self.parent1 = self.population[i]

			if rankI > rank1 and rankI < rank2:
				self.parent2 = self.population[i]
#			if self.parent2 != None and self.rank(self.parent2) < self.rank(self.parent1):
#				aux = self.parent1
#				self.parent1 = self.parent2
#				self.parent2 = aux

	def evolve(self):
		#Evolve a kind of Network to have its avoidance the minimal as possible

		#Generates a new random population
		self.randomPopulate()
		#Selects the better ones
		self.selection()

		#Shows the parents rank
		rank1 = self.rank(self.parent1)
		print "Parent1: ",rank1
		rank2 = self.rank(self.parent2)
		print "Parent2: ",rank2,"\n"

		#saves the state of parents in a auxiliary variable
		lastP1 = self.parent1
		lastP2 = self.parent2
		#set parent1 lifetimecounter to 0
		lifetimeCounter = 0

		#Loop for start the evolution process
		while  rank1 > self.idealFitness:

			#Generate a population with parents
			self.populate(self.parent1, self.parent2, self.populationSize)

			#Natural selection happens
			self.selection()

			print "|"+self.name+"|"

			#Shows the LifetimeCounter state on command line
			#and if it pops the limit, the parent die as the better solution
			if lifetimeCounter > self.lifetimeCounter:
				print "Network Parents reached lifetime limit!"
				break
			else:
				print "Parent Life-Time:",lifetimeCounter

			#Checks if the parent 1 have changed
			if lastP1 == self.parent1:
				lifetimeCounter = lifetimeCounter + 1
				lastP1 = self.parent1
			else:
				#If changed it start a new lifetime counter
				lifetimeCounter = 0
				lastP1 = self.parent1

			#Shows the Ranks on the screen
			rank1 = self.rank(self.parent1)
			print "Rank Parent1: ",rank1
			rank2 = self.rank(self.parent2)
			print "Rank Parent2: ",rank2

			print "||||||||||Parent1|||||||||"

			#Displays the Truth Table for each deserved Inputs to each parent Network Outputs
			for i in self.deservedInputs:
				z = self.parent1.activateNetwork(i)
				if z > [0.5]:
					print "Activation:\t",i,z
					print "Trigger:\t",i,"=",1
				else:
					print "Activation:\t",i,z
					print "Trigger:\t",i,"=",0

			print "||||||||||Parent2|||||||||"

			for i in self.deservedInputs:
				z = self.parent2.activateNetwork(i)
				if z > [0.5]:
					print "Activation:\t",i,z
					print "Trigger:\t",i,"=",1
				else:
					print "Activation:\t",i,z
					print "Trigger:\t",i,"=",0

			#Loading bar...
			print "Loading","."*(lifetimeCounter%30)

			#Overwrite and saves the data of the better parent at each cicle
			self.parent1.save(self.name+".ann")

			if rank1 <= self.idealFitness:
				break

		self.parent1.save(self.name+".ann")


###	TESTS




### Deserved Inputs&outputs test
#print n.getDeservedOutputs()
#print n.getDeservedInputs()

#N = network.Network()
#N.newRandom(2,1,3,2)
#p = N
#l = p.getInputLayer()
#il = l.getDendritesList()
#print il
#neu = il[0].getNeuronList()
#print neu
#N1 = network.Network()
#N1.newRandom(2,1,3,1)
#n.setParent1(N)
#n.setParent2(N1)
#n.randomPopulate()
#n.selection()
#print (n.getParent1().activateNetwork([1,1]))
#p = n.getParent1()
#l = p.getInputLayer()
#il = l.getDendritesList()
#neu = il[0].getNeuronList()
#print neu
#print (n.getParent2().activateNetwork([1,1]))
#p = n.getParent2()
#l = p.getInputLayer()
#il = l.getDendritesList()
#n = il[0].getNeuronList()
#print neu
#l = p.getHiddenLayer()
#l = l.getDendritesList()
#print len(l)

#print n.getParent1().activateNetwork([1,0])
#print n.getParent1().activateNetwork([0,1])
#print n.getParent1().activateNetwork([0,0])
#print n.getParent1().activateNetwork([1,1,0])
#print n.getParent1().activateNetwork([1,0,1])
#print n.getParent1().activateNetwork([0,1,1])
#print n.getParent1().activateNetwork([0,0,0])
### randomPopulate test
#print len(n.population)
###
#z = network.Network()
#z = z.load("and.ann")
#y = network.Network()
#y = y.load("or.ann")
### Rank test
#print n.rank(z)
#print n.rank(y)
###

#print z.activateNetwork([1,1])

#n.setParent1(z)
#n.setParent2(y)

### Selection test
#n.selection()
#n.selection()
###

#print n.rank(n.getParent1())
#print n.rank(n.getParent2())

###	deepcopy test	###
#m = network.Network()
#print m
#m = m.load("or.ann")
#y = m
#print m, y
#y = copy.deepcopy(m)
#print y
#
#print m.activateNetwork([1,1])
#print y.activateNetwork([1,1])
###

#n.mutation(n.getParent1())
#print n.rank(n.getParent1())
#n.mutation(n.getParent2())
#print n.rank(n.getParent2())

#z = n.crossover(n.getParent1(),n.getParent2())
#print n.rank(z)

#Steele, James. Building Applications with Android SDK. 2ª Edição 2013



###
#n = Neural()	#object instance

#n.setDeservedInputs([[1,1],[1,0],[0,1],[0,0]])
#list with Deserved Inputs to my network

#n.setDeservedOutputs([[1],[0],[0],[0]])
#list with Deserved Output for each element in input list

#triggers are set as X > 0.5 to be True(1)
#this means like XOR operation over the ipunts

#n.setPopulationSize(200)	#qtty of individuals to be tested as solutions
#n.setMutationRate(0.7)	#mutation rate over individuals in new population
#n.setIdealFitness(0.01)	#ideal solution must have this rank

#n.setNetworksLenghts(2,1,3,1)
#first parameter is qtty of neurons in input layer
#next is qtty of hidden layers
#next is qtty of neurons in hidden layers
#and last is qtty of neurons in output layer

#n.setLifetimeCounter(100)
#stop clause if parent1 survive this amout of population without shifting

#n.evolve()	#start natural selection iterations over populations

#it save the trainned network when finish evolve iterations...
