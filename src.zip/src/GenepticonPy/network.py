"""
The MIT License (MIT)

Copyright (c) 2016 Eduardo Henrique Vieira dos Santos

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""


import layer, pickle, copy

class Network:

	#The Network means the intermediary between its containing Layers

	#The Network recieve external Inputs list, inject it into the Input Layer and Activate itself Layers
	
	################
	### Settings ###
	################

	def __init__(self):
		self.setInputLayer(None)	#Set the Network InputLayer
		self.setHiddenLayer(None)	#Set the Network Hidden Layer
		self.setOutputLayer(None)	#Set the Network Output Layer

		self.setInputXn([])	#List of inputs to pass through the Network
		self.ejectOutputXn()	#Create an instance of the outputs list

	############
	## Layers ##
	############

	def newRandom(self, heightInputLayer, lenHiddenLayer, heightHiddenLayer, heightOutputLayer):
		#Reconfigure the Network with each randomed Layer settiings as below:
		#heightInputLayer especifyes the amount of Neurons into the first and only Dendrite into the Input Layer
		#lenHiddenLayer especifyes the amount of Dendrites inside the Hidden Layer
		#heightHiddenLayer especifyes the amount of Neurons inside each Dendrite into the Hidden Layer
		#heightOutputLayer especifyes the amount of Neurons inside the last and only Dendrite into the Output Layer

		#Set for Input layer
		lay = layer.Layer()
		lay.newRandom(1, heightInputLayer)
		self.setInputLayer(lay)

		#Set for Hidden Layer
		lay = layer.Layer()
		lay.newRandom(lenHiddenLayer, heightHiddenLayer)
		self.setHiddenLayer(lay)

		#Set for Output Layer
		lay = layer.Layer()
		lay.newRandom(1, heightOutputLayer)
		self.setOutputLayer(lay)
	
	def save(self, name):
		#Save the present Network using pickle
		pickle_out = open(name, "wb")
		pickle.dump(self, pickle_out)
		pickle_out.close()

	def load(self, name):
		#Load another Network set using pickle
		pickle_in = open(name, "rb")
		z = pickle.load(pickle_in)
		pickle_in.close()
		return z

	def setInputLayer(self, lay):
		#Sets the Input Layer
		self.inputLayer = lay
	def getInputLayer(self):
		return self.inputLayer

	def setHiddenLayer(self, lay):
		#Sets the Hidden Layer
		self.hiddenLayer = lay
	def getHiddenLayer(self):
		return self.hiddenLayer

	def setOutputLayer(self, lay):
		#Sets the Output Layer
		self.outputLayer = lay
	def getOutputLayer(self):
		return self.outputLayer

	def setLayers(self, inLay, hidLay, outLay):
		#Set each needed Layer to the Network
		self.inputLayer = inLay
		self.hiddenLayer = hidLay
		self.outputLayer = outLay

	######################
	## Inputs & Outputs ##
	######################

	def setInputXn(self,nXn):
		#Read the Network Inputvalues as a list
		self.inputXn = nXn
	def getInputXn(self):
		#Shows the Network Inputvalue as a list
		return self.inputXn
	def injectInputXn(self):
		#Inject the Network Inputlist into the Neurons of the Input Layer
		self.inputLayer.setInputXn(self.inputXn)
		gw = []
		for i in self.inputXn:
			gw.append(1)
		self.inputLayer.setInputGWn(gw)

	def ejectOutputXn(self):
		#Eject the Activation values of Neurons from the Output Layer to the Network Output values
		self.outputXn = []
		if self.outputLayer != None:
			last = self.outputLayer.getDendritesList()
			for i in last:
				neuronL = i.getNeuronList()
				for j in neuronL:
					self.outputXn.append(j.getAct())
	def getOutputXn(self):
		#Shows the Network Output as a list
		return self.outputXn

	################
	### Purposes ###
	################

	def activateInputLayer(self):
		#Input Layer Activation type
		#Inject the Network Input list into the Input Layer
		self.injectInputXn()
		#Activate the Input Layer
		self.inputLayer.activateInputLayer()

	def activateHiddenLayer(self):
		#Hidden Layer Activation type
		#Set the Input Layer Activations output list into the Hidden Layer input list
		self.hiddenLayer.setInputXn(self.inputLayer.getOutputXn())
		#Set the Input Layer Global Weights output list into the Hidden Layer Global Wieghts input list
		self.hiddenLayer.setInputGWn(self.inputLayer.getOutputGWn())
		#Activate the Hidden Layer
		self.hiddenLayer.activateLayer()

	def activateOutputLayer(self):
		#Output Layer Activation Type
		#Set the Hidden Layer Activations output list into the Output Layer input list
		self.outputLayer.setInputXn(self.hiddenLayer.getOutputXn())
		#Set the Hidden Layer Global Weights output list into the Output Layer Global Wieghts input list
		self.outputLayer.setInputGWn(self.hiddenLayer.getOutputGWn())
		#Activate the Output Layer
		self.outputLayer.activateLayer()

	def actSettedNetwork(self):
		#Read the inputs setted, Activate the whole Network and return its Activation values
		self.injectInputXn()
		#Activate each Netowrk Layer
		self.activateInputLayer()
		self.activateHiddenLayer()
		self.activateOutputLayer()
		#Eject the Output Layer Activation list to the Network
		self.ejectOutputXn()
		#Return the value
		return self.getOutputXn()

	def activateNetwork(self, nXn):
		#Read the given inputs list, Activate the whole Network and return its Activation values
		#Set the given inputs into the Network Input
		self.setInputXn(nXn)
		#Inject the Network Input into the Input Layer
		self.injectInputXn()
		#Activate each Network Layer
		self.activateInputLayer()
		self.activateHiddenLayer()
		self.activateOutputLayer()
		#Eject the Output Layer Activation list to the Network
		self.ejectOutputXn()
		#Return the value
		return self.getOutputXn()

###
#pickle_out = open("Network.ann", "wb")
#N = Network()
#pickle.dump(x, pickle_out)
#pickle_out.close()
##
#i = layer.Layer()
#h = layer.Layer()
#o = layer.Layer()
#i.newRandom(1,2)
#h.newRandom(1,2)
#o.newRandom(1,10)
#N = Network()
#N.setLayers(i,h,o)
#N.newRandom(2,1,3,1)
#l = N.getInputLayer()
#il = l.getDendritesList()
#nl = il[0].getNeuronList()
#print len(nl)
#p = N
#l = p.getInputLayer()
#il = l.getDendritesList()
#print il
#neu = il[0].getNeuronList()
#print neu
##

###
#N.setInputXn([0.3,0.2])
#N.injectInputXn()
###

#k = N.activateNetwork([0, 0])
#print k
#N.save("novarede")
#N.load("novarede")
#k = N.activateNetwork([0, 0])
#print k
#i = N.getInputLayer()
#print i.getOutputXn()
#ill = i.getDendritesList()
#il = ill[0]
#print il.getOutputXn()
#nl = il.getNeuronList()
#print nl
#for i in range(10):
#	print k
#	k = N.activateNetwork([k[0], k[1]])

#print N.activateNetwork([0.9, 0.9])
#print N.activateNetwork([0.5, 0.5])
#N.newRandom(5,2,10,2)
#print N.activateNetwork([0.3, 0.2])
#print N.activateNetwork([0.9, 0.9])
#print N.activateNetwork([0.5, 0.5])
###
#l = N.getInputLayer()
#illist = l.getDendritesList()
#il = illist[0]
#nlist = il.getNeuronList()
#n = nlist[1]
#print n.getSumXn()
###
