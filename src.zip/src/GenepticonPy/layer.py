"""
The MIT License (MIT)

Copyright (c) 2016 Eduardo Henrique Vieira dos Santos

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""

import dendrites

class Layer:
	
	#Layer means a coating layer containing Dendrites
	#A Layer belongs to a Network

	#Layers inject the Xn and GWn of other Layers or Network Inputs into its Neurons
	#Then Dendrites are activated
	#The last Dendrites Neurons Activation and Global Weight values are ejected from the Dendrites as lists
	#Layers recieve other Layers or Network inputs and inject it into the first Dendrites,
	#then activate them in chain and get the last Dendrites outputs


	################
	### Settings ###
	################

	def __init__(self):
		self.setDendritesList([])	#List of Dendrites inside the Layer
		self.setInputXn([])	#List of Xn inputs where X is another Layer output ou a Network Input
		self.setInputGWn([])	#List of Global Weights from those Inputs
		self.setOutputXn()	#Sum of inner Neurons Activation inside the last Dendrites in chain
		self.setOutputGWn()	#Sum of inner Global Weights inside the last Dendrites in chain

	#################
	## Dendrites ##
	#################

	def setDendritesList(self,nLis):
		#DendritesList must be a list type object
		self.DendritesList = nLis
	def getDendritesList(self):
		return self.DendritesList

	######################
	## Inputs & Outputs ##
	######################

	def setInputXn(self,nXn):
		#Set the list of Xn inputs where X is another Layer output or a Network Input
		self.inputXn = nXn
	def getInputXn(self):
		return self.inputXn

	def setInputGWn(self,nLis):
		#Set the Global Weights from those Inputs if its Neurons activations
		self.inputGWn = nLis
	def getInputGWn(self):
		return self.inputGWn

	def setOutputXn(self):
		#Eject the last Dendrites Neurons Activation values into outputXn[]
		self.outputXn = []
		if len(self.DendritesList) != 0:
			last = self.DendritesList[-1]
			self.outputXn = last.getOutputXn()
	def getOutputXn(self):
		#Get last Dendrites Neurons Activation list
		return self.outputXn

	def setOutputGWn(self):
		#Eject the last Dendrites Neurons Global Weight values into outputGWn[]
		self.outputGWn = []
		if len(self.DendritesList) != 0:
			last = self.DendritesList[-1]
			self.outputGWn = last.getOutputGWn()
	def getOutputGWn(self):
		#Get the last Dendrites Neurons Global Weights list
		return self.outputGWn

	################
	### Purposes ###
	################

	def newRandom(self, lenght, lenghtInners):
		#Reconfigure Layer to a list of Dendrites with a lenght, each with a lenght of its Neurons list
		self.DendritesList = []
		for i in range(lenght):
			n = dendrites.Dendrites()
			n.newRandom(lenghtInners)
			self.DendritesList.append(n)
	
	def injectXn(self):
		#Inject the Layer Xn inputs list into the first Dendrites in chain
		if len(self.DendritesList) != 0:
			firstDendrites = self.DendritesList[0]
			firstDendrites.setInputXn(self.inputXn)

	def injectGWn(self):
		#Inject the Layer Global Weight inputs list into the first Dendrites in chain
		if len(self.DendritesList) != 0:
			firstDendrites = self.DendritesList[0]
			firstDendrites.setInputGWn(self.inputGWn)

	def activateDendrites(self):
		#Activate each Dendrites in chain inside the Layer
		if len(self.DendritesList) != 0:
			last = None
			for i in self.DendritesList:
				if i == self.DendritesList[0]:
					#The first Dendrites becomes activated and is treated as the last
					i.activateDendrites()
					last = i
				else:
					#Each Dendrites pass its Outputs to the next Dendrites in chain
					i.setInputXn(last.getOutputXn())
					i.setInputGWn(last.getOutputGWn())
					#The Dendrites becomes activated and is treated as the last
					i.activateDendrites()
					last = i

	def activateInputLayer(self):
		#Input Layer activation type
		#Each Network input is inserted into its correspondent Neuron
		self.injectXn()
		self.injectGWn()
		#The Dendrites inside are activated in chain
		if len(self.DendritesList) != 0:
			last = None
			for i in self.DendritesList:
				if i == self.DendritesList[0]:
					#The first Dendrites becomes activated and is treated as the last
					i.activateInputDendrites()
					last = i
				else:
					#Each Dendrites pass its Outputs to the next Dendrites in chain
					i.setInputXn(last.getOutputXn())
					i.setInputGWn(last.getOutputGWn())
					#The Dendrites becomes activated and is treated as the last
					i.activateInputDendrites()
					last = i
		#eject the Neurons outputs
		self.setOutputXn()	#eject the Neurons Activation values from the last Dendrites
		self.setOutputGWn()	#eject the Neurons Global Weight values from the last Dendrites

	def activateLayer(self):
		#Each Network input is inserted into its correspondent Neuron
		self.injectXn()
		self.injectGWn()
		#The Dendrites become activated
		self.activateDendrites()
		#eject the Neurons outputs
		self.setOutputXn()
		self.setOutputGWn()


##tests##
#l = Layer()
#l.newRandom(1,10)
#ilist = l.getDendritesList()
#i = ilist[0]
#nlist = i.getNeuronList()
#n = nlist[0]

#l.setInputXn([0.2,0.3,0.4,0.5])
#l.setInputGWn([1,1,1,1])
#l.activateLayer()
#print l.getOutputXn()
