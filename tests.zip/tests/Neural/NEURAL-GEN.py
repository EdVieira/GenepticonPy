#encoding: utf-8

from GenepticonPy import neural

n = neural.Neural()	#object instance

n.setName("XOR")

n.setDeservedInputs([[1,1],[1,0],[0,1],[0,0]])
#list with deserved inputs to my network

n.setDeservedOutputs([[0],[1],[1],[0]])
#list with deserved output for each element in input list

#triggers are set as X > 0.5 to be True(1)
#this means like XOR operation over the ipunts

n.setPopulationSize(200)	#qtty of individuals to be tested as solutions
n.setMutationRate(0.7)	#mutation rate over individuals in new population
n.setIdealFitness(0.01)	#ideal solution must have this rank

n.setNetworksLengths(2,2,3,1)
#first parameter is qtty of neurons in input layer
#next is qtty of hidden layers
#next is qtty of neurons in hidden layers //set 2 layers for non linear problems
#and last is qtty of neurons in output layer

n.setLifetimeCounter(200)
#stop clause if parent1 survive this amout of population without shifting
#if you want to let it training infinitely you can use like:
#n.setLifetimeCounter("inf")

n.evolve()	#start natural selection iterations over populations

#it saves the trainned network when finish evolve iterations...
