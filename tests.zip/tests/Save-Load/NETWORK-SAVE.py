from GenepticonPy import network, layer, dendrites, neuron

#In this code a Network that solves AND operation is created then saved

net = network.Network()
lay = layer.Layer()
lay1 = layer.Layer()
lay2 = layer.Layer()
ilay = dendrites.Dendrites()
ilay1 = dendrites.Dendrites()
ilay2 = dendrites.Dendrites()
neu = neuron.Neuron(1,1,0,1,1)
neu1 = neuron.Neuron(1,1,0,1,1)
ilay.setNeuronList([neu,neu1])
lay.setDendritesList([ilay])
net.setInputLayer(lay)


neu2 = neuron.Neuron(0.6,1,0,1,1)
neu3 = neuron.Neuron(0.6,1,0,1,1)
ilay1.setNeuronList([neu2, neu3])
lay1.setDendritesList([ilay1])
net.setHiddenLayer(lay1)

neu4 = neuron.Neuron(1,1,0,0,0)
ilay2.setNeuronList([neu4])
lay2.setDendritesList([ilay2])
net.setOutputLayer(lay2)


z = net.activateNetwork([1,1])
test = True
if z[0] >= 0.5:
	test = True
else:
	test = False
print "1-1",z, test

z = net.activateNetwork([1,0])
test = True
if z[0] >= 0.5:
	test = True
else:
	test = False
print "1-0",z, test

z = net.activateNetwork([0,1])
test = True
if z[0] >= 0.5:
	test = True
else:
	test = False
print "0-1", z, test

z = net.activateNetwork([0,0])
test = True
if z[0] >= 0.5:
	test = True
else:
	test = False
print "0-0", z, test

#Save function
net.save("test")