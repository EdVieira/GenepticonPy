from GenepticonPy import network, layer, dendrites, neuron

#In this code a Network that solves the AND operation is loaded then tested

n = network.Network()
#Load function
n = n.load("test")

z = n.activateNetwork([1,1])
if z > [0.5]:
	print z
	print 1
else:
	print z
	print 0

z = n.activateNetwork([1,0])
if z > [0.5]:
	print z
	print 1
else:
	print z
	print 0

z = n.activateNetwork([0,1])
if z > [0.5]:
	print z
	print 1
else:
	print z
	print 0

z = n.activateNetwork([0,0])
if z > [0.5]:
	print z
	print 1
else:
	print z
	print 0