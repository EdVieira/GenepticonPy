from GenepticonPy import network, layer, dendrites, neuron

#Create Network instance
net = network.Network()
#Create Layers instance
lay = layer.Layer()
lay1 = layer.Layer()
lay2 = layer.Layer()
#Create InnerLayer instances
ilay = dendrites.Dendrites()
ilay1 = dendrites.Dendrites()
ilay2 = dendrites.Dendrites()
#Create the Input Layer Neurons
neu = neuron.Neuron(1,1,0,1,1)
neu1 = neuron.Neuron(1,1,0,1,1)
#Attach them to the InnerLayer
ilay.setNeuronList([neu,neu1])
#Attach the InnerLayer to the Layer
lay.setDendritesList([ilay])
#Attach the Layer to the Network as a Input Layer
net.setInputLayer(lay)


#Create the Hidden Layer Neurons
neu2 = neuron.Neuron(0.6,1,0,1,1)
neu3 = neuron.Neuron(0.6,1,0,1,1)
#Attach them to the InnerLayer
ilay1.setNeuronList([neu2, neu3])
#Attach the InnerLayer to the Layer
lay1.setDendritesList([ilay1])
#Attach the Layer to the Network as a Input Layer
net.setHiddenLayer(lay1)

#Create the Output Layer Neurons
neu4 = neuron.Neuron(1,1,0,0,0)
#Attach them to the InnerLayer
ilay2.setNeuronList([neu4])
#Attach the InnerLayer to the Layer
lay2.setDendritesList([ilay2])
#Attach the Layer to the Network as a Input Layer
net.setOutputLayer(lay2)

#Tests

z = net.activateNetwork([1,1])
test = True
if z[0] >= 0.5:
	test = True
else:
	test = False
print "1-1",z, test

z = net.activateNetwork([1,0])
test = True
if z[0] >= 0.5:
	test = True
else:
	test = False
print "1-0",z, test

z = net.activateNetwork([0,1])
test = True
if z[0] >= 0.5:
	test = True
else:
	test = False
print "0-1", z, test

z = net.activateNetwork([0,0])
test = True
if z[0] >= 0.5:
	test = True
else:
	test = False
print "0-0", z, test